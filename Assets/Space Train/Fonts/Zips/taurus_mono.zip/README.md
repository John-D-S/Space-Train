Taurus Mono Outline
========
_by [Tyler Finck](http://www.finck.co)_

The regular and bold weights of Taurus Mono Outline. Taurus Mono is a new (2014) round monospace family, inspired by space! Four other styles are available (each with two weights) at [finck.co/taurus](http://www.finck.co/taurus).

![Taurus Mono Outline](https://raw.githubusercontent.com/sursly/taurusmono/master/preview.jpg)

[Download Taurus Mono Outline](https://github.com/sursly/taurusmono/archive/master.zip)



